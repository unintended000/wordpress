<?php 
	global $WOWTheme;
	
	get_header(); 
?>
			<h1 class="page-title"><?php echo $WOWTheme->_( 'errortext' ); ?></h1>
			<?php echo $WOWTheme->_( 'errorsolution' ); ?>
<?php
	get_footer();
?>